﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Telestreaming
{
    public partial class Form3 : Form
    {
        public string returnTXT { get; set; }
        public Form3()
        {
            InitializeComponent();
            this.Chk_RN.KeyDown += Press_Enter;

        }

        public Form2 fr2; //값을 넘기는 용도

        private void Press_Enter(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                button1_Click(sender, e);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Form3");
            returnTXT = Chk_RN.Text.ToString();
            fr2.Btemp = returnTXT;

            fr2.Roomlabel[fr2.Bcnt].Text = "Room" + (fr2.Bcnt + 1).ToString() + Environment.NewLine + "방송인     : " + fr2.ID + Environment.NewLine + "방송 제목 : " + fr2.Btemp;
            fr2.Roomlabel[fr2.Bcnt].Visible = true;
            fr2.Bcnt++;
            fr2.PBroadcast.Enabled = false;
            this.Close();
        }
    }
}
