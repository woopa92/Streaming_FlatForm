﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Telestreaming
{
    public partial class Form5 : Form //방송 보는 클라이언트
    {
        public string ID { get; set; }
        public string Rplayer { get; set; }
        public string Rname { get; set; }
        public string TXT { get; set; }

      //  List<string> Chat { get; set; }

        public Form5(string ID, string RPlayer, string Rname)
        {
            InitializeComponent();
            this.ID = ID;
            this.Rplayer = RPlayer;
            this.Rname = Rname;

            this.Input_text.KeyDown += Press_Enter;
            //    Chat = new List<string>();
            this.Text = Rname;

            //서버에서 해당 방에 있는 인원에 대한 정보를 받아와야 한다.
            //자싡의 에 대한 위치에 대한 정보도 서버로 보애냐 함.
            //현재는 자신의 이름만 넣을 수 있게 설정해 놓음
            Personview.AppendText(ID);

        }
        private void Press_Enter(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                inputenter_Click(sender, e);
            }
        }

        private void GoSupport_Click(object sender, EventArgs e)
        {

        }

        private void inputenter_Click(object sender, EventArgs e)
        {
            TXT = ID + " : " + Input_text.Text;
            //서버랑 채팅에 대한 통신 필요
            //Chat.Add(TXT);
            Chatview.AppendText(TXT+Environment.NewLine);
            Input_text.Text = "";
            
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
    }
}
