﻿namespace Telestreaming
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Input_text = new System.Windows.Forms.TextBox();
            this.Inputenter = new System.Windows.Forms.Button();
            this.GoSupport = new System.Windows.Forms.Button();
            this.StreamingPic = new System.Windows.Forms.PictureBox();
            this.Chatview = new System.Windows.Forms.RichTextBox();
            this.Personview = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.StreamingPic)).BeginInit();
            this.SuspendLayout();
            // 
            // Input_text
            // 
            this.Input_text.Location = new System.Drawing.Point(23, 525);
            this.Input_text.Name = "Input_text";
            this.Input_text.Size = new System.Drawing.Size(576, 21);
            this.Input_text.TabIndex = 1;
            // 
            // Inputenter
            // 
            this.Inputenter.Location = new System.Drawing.Point(622, 523);
            this.Inputenter.Name = "Inputenter";
            this.Inputenter.Size = new System.Drawing.Size(75, 23);
            this.Inputenter.TabIndex = 2;
            this.Inputenter.Text = "전송";
            this.Inputenter.UseVisualStyleBackColor = true;
            this.Inputenter.Click += new System.EventHandler(this.inputenter_Click);
            // 
            // GoSupport
            // 
            this.GoSupport.Location = new System.Drawing.Point(622, 465);
            this.GoSupport.Name = "GoSupport";
            this.GoSupport.Size = new System.Drawing.Size(75, 23);
            this.GoSupport.TabIndex = 3;
            this.GoSupport.Text = "후원";
            this.GoSupport.UseVisualStyleBackColor = true;
            this.GoSupport.Click += new System.EventHandler(this.GoSupport_Click);
            // 
            // StreamingPic
            // 
            this.StreamingPic.Location = new System.Drawing.Point(23, 13);
            this.StreamingPic.Name = "StreamingPic";
            this.StreamingPic.Size = new System.Drawing.Size(576, 356);
            this.StreamingPic.TabIndex = 4;
            this.StreamingPic.TabStop = false;
            // 
            // Chatview
            // 
            this.Chatview.Location = new System.Drawing.Point(23, 387);
            this.Chatview.Name = "Chatview";
            this.Chatview.Size = new System.Drawing.Size(576, 132);
            this.Chatview.TabIndex = 5;
            this.Chatview.Text = "";
            // 
            // Personview
            // 
            this.Personview.Location = new System.Drawing.Point(640, 12);
            this.Personview.Name = "Personview";
            this.Personview.Size = new System.Drawing.Size(179, 132);
            this.Personview.TabIndex = 6;
            this.Personview.Text = "";
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(950, 580);
            this.Controls.Add(this.Personview);
            this.Controls.Add(this.Chatview);
            this.Controls.Add(this.StreamingPic);
            this.Controls.Add(this.GoSupport);
            this.Controls.Add(this.Inputenter);
            this.Controls.Add(this.Input_text);
            this.Name = "Form5";
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.StreamingPic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox Input_text;
        private System.Windows.Forms.Button Inputenter;
        private System.Windows.Forms.Button GoSupport;
        private System.Windows.Forms.PictureBox StreamingPic;
        private System.Windows.Forms.RichTextBox Chatview;
        private System.Windows.Forms.RichTextBox Personview;
    }
}