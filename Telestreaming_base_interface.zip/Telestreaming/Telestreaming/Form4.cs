﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Telestreaming
{
    public partial class Form4 : Form //방송하는 경우의 클라이언트 부분
    {
        public Form4()
        {
            InitializeComponent();
        }
    }
}
