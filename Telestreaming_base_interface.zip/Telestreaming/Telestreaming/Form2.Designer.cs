﻿namespace Telestreaming
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ID_Dp = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.LogoutB = new System.Windows.Forms.Label();
            this.PBroadcast = new System.Windows.Forms.Button();
            this.Room1 = new System.Windows.Forms.Label();
            this.Room2 = new System.Windows.Forms.Label();
            this.Room3 = new System.Windows.Forms.Label();
            this.Room4 = new System.Windows.Forms.Label();
            this.Room5 = new System.Windows.Forms.Label();
            this.Room6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ID_Dp
            // 
            this.ID_Dp.AutoSize = true;
            this.ID_Dp.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold);
            this.ID_Dp.Location = new System.Drawing.Point(493, 23);
            this.ID_Dp.Name = "ID_Dp";
            this.ID_Dp.Size = new System.Drawing.Size(61, 16);
            this.ID_Dp.TabIndex = 0;
            this.ID_Dp.Text = "ID_chk";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(582, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "환영합니다";
            // 
            // LogoutB
            // 
            this.LogoutB.AutoSize = true;
            this.LogoutB.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold);
            this.LogoutB.Location = new System.Drawing.Point(695, 23);
            this.LogoutB.Name = "LogoutB";
            this.LogoutB.Size = new System.Drawing.Size(76, 16);
            this.LogoutB.TabIndex = 2;
            this.LogoutB.Text = "로그아웃";
            this.LogoutB.Click += new System.EventHandler(this.LogoutB_Click);
            // 
            // PBroadcast
            // 
            this.PBroadcast.Location = new System.Drawing.Point(670, 525);
            this.PBroadcast.Name = "PBroadcast";
            this.PBroadcast.Size = new System.Drawing.Size(100, 31);
            this.PBroadcast.TabIndex = 3;
            this.PBroadcast.Text = "방송하기";
            this.PBroadcast.UseVisualStyleBackColor = true;
            this.PBroadcast.Click += new System.EventHandler(this.PBroadcast_Click);
            // 
            // Room1
            // 
            this.Room1.AutoSize = true;
            this.Room1.Font = new System.Drawing.Font("굴림", 15F);
            this.Room1.Location = new System.Drawing.Point(39, 80);
            this.Room1.Name = "Room1";
            this.Room1.Size = new System.Drawing.Size(111, 60);
            this.Room1.TabIndex = 4;
            this.Room1.Text = "Room1   \r\n방송인     :\r\n방송 제목 :";
            this.Room1.Click += new System.EventHandler(this.Room1_Click);
            // 
            // Room2
            // 
            this.Room2.AutoSize = true;
            this.Room2.Font = new System.Drawing.Font("굴림", 15F);
            this.Room2.Location = new System.Drawing.Point(39, 160);
            this.Room2.Name = "Room2";
            this.Room2.Size = new System.Drawing.Size(111, 60);
            this.Room2.TabIndex = 5;
            this.Room2.Text = "Room2   \r\n방송인     :\r\n방송 제목 :";
            this.Room2.Click += new System.EventHandler(this.Room2_Click);
            // 
            // Room3
            // 
            this.Room3.AutoSize = true;
            this.Room3.Font = new System.Drawing.Font("굴림", 15F);
            this.Room3.Location = new System.Drawing.Point(39, 243);
            this.Room3.Name = "Room3";
            this.Room3.Size = new System.Drawing.Size(111, 60);
            this.Room3.TabIndex = 6;
            this.Room3.Text = "Room3   \r\n방송인     :\r\n방송 제목 :";
            this.Room3.Click += new System.EventHandler(this.Room3_Click);
            // 
            // Room4
            // 
            this.Room4.AutoSize = true;
            this.Room4.Font = new System.Drawing.Font("굴림", 15F);
            this.Room4.Location = new System.Drawing.Point(39, 340);
            this.Room4.Name = "Room4";
            this.Room4.Size = new System.Drawing.Size(111, 60);
            this.Room4.TabIndex = 7;
            this.Room4.Text = "Room4   \r\n방송인     :\r\n방송 제목 :";
            this.Room4.Click += new System.EventHandler(this.Room4_Click);
            // 
            // Room5
            // 
            this.Room5.AutoSize = true;
            this.Room5.Font = new System.Drawing.Font("굴림", 15F);
            this.Room5.Location = new System.Drawing.Point(39, 439);
            this.Room5.Name = "Room5";
            this.Room5.Size = new System.Drawing.Size(111, 60);
            this.Room5.TabIndex = 8;
            this.Room5.Text = "Room5   \r\n방송인     :\r\n방송 제목 :";
            this.Room5.Click += new System.EventHandler(this.Room5_Click);
            // 
            // Room6
            // 
            this.Room6.AutoSize = true;
            this.Room6.Font = new System.Drawing.Font("굴림", 15F);
            this.Room6.Location = new System.Drawing.Point(39, 541);
            this.Room6.Name = "Room6";
            this.Room6.Size = new System.Drawing.Size(111, 60);
            this.Room6.TabIndex = 9;
            this.Room6.Text = "Room6   \r\n방송인     :\r\n방송 제목 :";
            this.Room6.Click += new System.EventHandler(this.Room6_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 629);
            this.Controls.Add(this.Room6);
            this.Controls.Add(this.Room5);
            this.Controls.Add(this.Room4);
            this.Controls.Add(this.Room3);
            this.Controls.Add(this.Room2);
            this.Controls.Add(this.Room1);
            this.Controls.Add(this.PBroadcast);
            this.Controls.Add(this.LogoutB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ID_Dp);
            this.Name = "Form2";
            this.Text = "대기화면";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ID_Dp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LogoutB;
        public System.Windows.Forms.Button PBroadcast;
        private System.Windows.Forms.Label Room1;
        private System.Windows.Forms.Label Room2;
        private System.Windows.Forms.Label Room3;
        private System.Windows.Forms.Label Room4;
        private System.Windows.Forms.Label Room5;
        private System.Windows.Forms.Label Room6;
    }
}