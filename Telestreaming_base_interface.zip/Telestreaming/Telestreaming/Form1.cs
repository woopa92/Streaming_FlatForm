﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace Telestreaming
{
    public partial class Form1 : Form
    {
        public string InputID { get; set; }
        public string InputPW { get; set; }
        Form2 fr;
        TcpClient client;
        int checkid = 0;
        bool isMove;
        Point fpt;


        public Form1()
        {
            InitializeComponent();

           // pictureBox1.Image = Properties.Resource1.DGV_Title;
            //pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;

           // this.BackgroundImage = Properties.Resource1.LOGINbg;

            panel2.BackColor = Color.FromArgb(100, 255, 255, 255);

            panel3.Location = new Point(0, 25);
            panel3.Size = new Size(441, 283);
            panel3.Visible = false;
            this.CHK_PS.KeyDown += Press_Enter;
            
        }

        private void Login_Click(object sender, EventArgs e)
        {

            InputID = CHK_ID.Text;
            InputPW = CHK_PS.Text;

          
            if (InputID == "")
            {
                MessageBox.Show("아이디가 필요합니다.");
                CHK_ID.Text = "";
                CHK_PS.Text = "";
            }
            else if(InputPW == "")
            {
                MessageBox.Show("비밀번호가 필요합니다.");
                CHK_ID.Text = "";
                CHK_PS.Text = "";
            }
            else if(InputID != null && InputPW != null)
            {
                //서버를 통해서, 맞는지 확인


                //string message = "/login|" + CHK_ID.Text + "|" + CHK_PS.Text + "|";
                //string[] leaddata;
                //byte[] byteData = new byte[message.Length];
                //byteData = Encoding.UTF8.GetBytes(message);
                //client.GetStream().Write(byteData, 0, byteData.Length);
                //Array.Clear(byteData, 0x0, byteData.Length);
                //client.GetStream().Read(byteData, 0, byteData.Length);
                //leaddata = Encoding.UTF8.GetString(byteData).Split('|');
                //if(leaddata[0] == "1")
                //{
                //    NextForm();
                //}
                //if(leaddata[0] == "3")
                //{
                //    MessageBox.Show("아이디가 존재하지 않습니다.");
                //}
                //if(leaddata[0] == "2")
                //{
                //    MessageBox.Show("비밀번호가 일치하지 않습니다.");
                //}

                MessageBox.Show(InputID + ", " + InputPW);
                NextForm();
            }

        }

        private void Press_Enter(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                Login_Click(sender, e);
            }
        }

        private void NextForm()
        {
            this.Hide();
            //fr = new Form2(InputID, client);
            fr = new Form2(InputID);
            fr.FormClosed += new FormClosedEventHandler(CloseProgram);
            fr.ShowDialog();
        }

        private void CloseProgram(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //client = new TcpClient();
            //client.Connect("10.10.20.45", 4366);
        }

        private void ID_check_Click(object sender, EventArgs e)
        {
            string message = "/IDcheck|" + txb_ID.Text + "|";
            string[] readmessage;
            byte[] byteData = new byte[message.Length];
            byteData = Encoding.UTF8.GetBytes(message);
            client.GetStream().Write(byteData, 0, byteData.Length);
            int bytes = client.GetStream().Read(byteData, 0, byteData.Length);
            readmessage = Encoding.UTF8.GetString(byteData, 0, bytes).Split('|');
            MessageBox.Show(readmessage[0]);
            if (readmessage[0] == "2")
            {
                MessageBox.Show("사용가능한 아이디입니다.");
                checkid = 1;
            }
            else
            {
                MessageBox.Show("이미 사용중인 아이디입니다.");
            }
        }

        private void sign_up2_Click(object sender, EventArgs e)
        {
            if(txb_Name.Text == null)
            {
                MessageBox.Show("이름을 입력해주십시오.");
            }
            else if(txb_ID.Text == null)
            {
                MessageBox.Show("아이디를 입력해주십시오.");
            }
            else if(checkid == 0)
            {
                MessageBox.Show("아이디 중복환인을 해주십시오.");
            }
            else if(txb_pw.Text == null)
            {
                MessageBox.Show("비밀번호를 입력해주십시오.");
            }
            else if(txb_pwc.Text == null)
            {
                MessageBox.Show("비밀번호확인을 입력해주십시오.");
            }
            else if(txb_pw.Text != txb_pwc.Text)
            {
                MessageBox.Show("비밀번호가 일치하지 않습니다.");
            }
            else if(ckb_h.Checked == false && ckb_s.Checked == false)
            {
                MessageBox.Show("성별을 선택해주십시오.");
            }
            else
            {
                checkid = 0;
                Sign_up();
            }
        }

        public void Sign_up()
        {
            string message;
            if (ckb_h.Checked == true)
            {
                message = "/signup|" + txb_Name.Text + "|" + txb_ID.Text + "|" + txb_pw.Text + "|";
            }
            else
            {
                message = "/signup|" + txb_Name.Text + "|" + txb_ID.Text + "|" + txb_pw.Text + "|";
            }

            MessageBox.Show(message);
            byte[] byteData = new byte[message.Length];
            byteData = Encoding.UTF8.GetBytes(message);
            client.GetStream().Write(byteData, 0, byteData.Length);
            message = Encoding.UTF8.GetString(byteData);
            MessageBox.Show("회원가입을 완료했습니다.");
            panel3.Visible = false;
        }

        private void Cancle_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
        }

        private void sign_upx_Click(object sender, EventArgs e)
        {
            panel3.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            isMove = true;
            fpt = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMove && (e.Button & MouseButtons.Left) == MouseButtons.Left)
                this.Location = new Point(this.Left - (fpt.X - e.X), this.Top - (fpt.Y - e.Y));
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            isMove = false;
        }
    }
}
