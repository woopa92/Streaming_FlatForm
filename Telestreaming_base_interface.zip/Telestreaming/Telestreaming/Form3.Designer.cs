﻿namespace Telestreaming
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Broad_cast = new System.Windows.Forms.Label();
            this.Chk_RN = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Broad_cast
            // 
            this.Broad_cast.AutoSize = true;
            this.Broad_cast.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Broad_cast.Font = new System.Drawing.Font("굴림", 15F);
            this.Broad_cast.Location = new System.Drawing.Point(12, 34);
            this.Broad_cast.Name = "Broad_cast";
            this.Broad_cast.Size = new System.Drawing.Size(76, 20);
            this.Broad_cast.TabIndex = 0;
            this.Broad_cast.Text = "방 제목";
            // 
            // Chk_RN
            // 
            this.Chk_RN.Font = new System.Drawing.Font("굴림", 20F);
            this.Chk_RN.Location = new System.Drawing.Point(106, 25);
            this.Chk_RN.Name = "Chk_RN";
            this.Chk_RN.Size = new System.Drawing.Size(218, 38);
            this.Chk_RN.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(152, 87);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "확인";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(349, 134);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Chk_RN);
            this.Controls.Add(this.Broad_cast);
            this.Name = "Form3";
            this.Text = "방속 제목";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Broad_cast;
        private System.Windows.Forms.TextBox Chk_RN;
        private System.Windows.Forms.Button button1;
    }
}