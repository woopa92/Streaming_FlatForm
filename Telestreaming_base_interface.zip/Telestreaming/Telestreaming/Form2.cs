﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;


namespace Telestreaming
{
    public partial class Form2 : Form
    {
        public string ID { get; set; }
        public TcpClient client { get; set; }
        public int Bcnt { get; set; }//현재 방속 갯수
        public string Btemp { get; set;}

        public Label[] Roomlabel { get; set; }

        Form3 fr1; // 방제목 입력부분
        Form4 fr2; // 방송할 경우 들어가는 form
        Form5 fr3; // 방송을 볼 경우 들어가는 form


        public Form2(string ID)
        //public Form2(string ID, TcpClient client)
        {
            InitializeComponent();
            this.ID = ID;
            //this.client = client;

            string temp = "";
            if (ID.Length >= 6)
            {
                temp = ID.Substring(0, 5);
                temp += "...님";
                ID_Dp.Text = temp;
            }
            else
            {
                ID_Dp.Text = ID + "님";
            }

            Roomlabel = new Label[6];

            Roomlabel[0] = Room1;
            Roomlabel[1] = Room2;
            Roomlabel[2] = Room3;
            Roomlabel[3] = Room4;
            Roomlabel[4] = Room5;
            Roomlabel[5] = Room6;

            for(int i = 0; i < 6; i++)
            {
                Roomlabel[i].Visible = false;
            }

            Bcnt = 0;
        }

        private void LogoutB_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void PBroadcast_Click(object sender, EventArgs e) // 방송하는 것 클릭 경우
        {
            fr1 = new Form3();

            fr1.fr2 = this;
            fr1.Show();
            fr1.FormClosed += BoardcastStart;

            
        }

        private void BoardcastStart(object sender, FormClosedEventArgs e)
        {
            fr2 = new Form4();
            this.Hide();
            fr2.FormClosed += Boradcastclose;
            fr2.Show();
        }

        private void Boradcastclose(object sender, FormClosedEventArgs e)
        {
            this.Show();
            this.PBroadcast.Enabled = true;
        }

        private void Room1_Click(object sender, EventArgs e)
        {
            Roomchk(0);
        }

        private void Room2_Click(object sender, EventArgs e)
        {
            Roomchk(1);
        }

        private void Room3_Click(object sender, EventArgs e)
        {
            Roomchk(2);
        }

        private void Room4_Click(object sender, EventArgs e)
        {
            Roomchk(3);
        }

        private void Room5_Click(object sender, EventArgs e)
        {
            Roomchk(4);
        }

        private void Room6_Click(object sender, EventArgs e)
        {
            Roomchk(5);
        }

        private void Roomchk(int num)
        {
            //MessageBox.Show(Roomlabel[num].Text);
            string[] temp, temp1;
            string Rname = "";
            string Rplayer = "";
            temp = Roomlabel[num].Text.Split(':');
            for(int i = 0; i <temp.Length;i++)
            {
                //MessageBox.Show(temp[i]);
                if (i == 1)
                {
                    temp1 = temp[i].Split('\n');
                    //MessageBox.Show(temp1[0]);
                    Rplayer = temp1[0].Substring(0,temp1[0].Length -1);

                }
                else if(i == 2)
                {
                    temp1 = temp[i].Split('\n');
                    //MessageBox.Show(temp1[0]);
                    Rname = temp1[0];
                }
            }

            MessageBox.Show(Rplayer + ", " + Rplayer.Length.ToString() + "," + Rname + "," + Rname.Length.ToString());

            fr3 = new Form5(ID, Rplayer, Rname);
            this.Hide();
            fr3.FormClosed += Form5closes;
            fr3.Show();
        }

        private void Form5closes(object sender, FormClosedEventArgs e)
        {
            this.Show();
        }

    }
}
