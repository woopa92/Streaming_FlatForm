﻿namespace Telestreaming
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.sign_upx = new System.Windows.Forms.Button();
            this.CHK_PS = new System.Windows.Forms.TextBox();
            this.Passwordlb = new System.Windows.Forms.Label();
            this.CHK_ID = new System.Windows.Forms.TextBox();
            this.ID_Label = new System.Windows.Forms.Label();
            this.Login = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txb_Name = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txb_pwc = new System.Windows.Forms.TextBox();
            this.txb_pw = new System.Windows.Forms.TextBox();
            this.Cancle = new System.Windows.Forms.Button();
            this.sign_up2 = new System.Windows.Forms.Button();
            this.ID_check = new System.Windows.Forms.Button();
            this.txb_ID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ckb_h = new System.Windows.Forms.CheckBox();
            this.ckb_s = new System.Windows.Forms.CheckBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(441, 25);
            this.panel1.TabIndex = 7;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(45, 20);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button1.Location = new System.Drawing.Point(414, 1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(25, 25);
            this.button1.TabIndex = 9;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Controls.Add(this.sign_upx);
            this.panel2.Controls.Add(this.CHK_PS);
            this.panel2.Controls.Add(this.Passwordlb);
            this.panel2.Controls.Add(this.CHK_ID);
            this.panel2.Controls.Add(this.ID_Label);
            this.panel2.Controls.Add(this.Login);
            this.panel2.Location = new System.Drawing.Point(56, 56);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(318, 208);
            this.panel2.TabIndex = 8;
            // 
            // sign_upx
            // 
            this.sign_upx.Location = new System.Drawing.Point(179, 144);
            this.sign_upx.Name = "sign_upx";
            this.sign_upx.Size = new System.Drawing.Size(75, 23);
            this.sign_upx.TabIndex = 10;
            this.sign_upx.Text = "회원가입";
            this.sign_upx.UseVisualStyleBackColor = true;
            this.sign_upx.Click += new System.EventHandler(this.sign_upx_Click);
            // 
            // CHK_PS
            // 
            this.CHK_PS.Font = new System.Drawing.Font("굴림", 15F);
            this.CHK_PS.Location = new System.Drawing.Point(135, 87);
            this.CHK_PS.Name = "CHK_PS";
            this.CHK_PS.PasswordChar = '*';
            this.CHK_PS.Size = new System.Drawing.Size(155, 30);
            this.CHK_PS.TabIndex = 9;
            // 
            // Passwordlb
            // 
            this.Passwordlb.AutoSize = true;
            this.Passwordlb.BackColor = System.Drawing.Color.Transparent;
            this.Passwordlb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Passwordlb.Font = new System.Drawing.Font("돋움", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Passwordlb.ForeColor = System.Drawing.Color.Black;
            this.Passwordlb.Location = new System.Drawing.Point(26, 90);
            this.Passwordlb.Name = "Passwordlb";
            this.Passwordlb.Size = new System.Drawing.Size(93, 20);
            this.Passwordlb.TabIndex = 8;
            this.Passwordlb.Text = "비밀번호";
            // 
            // CHK_ID
            // 
            this.CHK_ID.Font = new System.Drawing.Font("굴림", 15F);
            this.CHK_ID.Location = new System.Drawing.Point(135, 42);
            this.CHK_ID.Name = "CHK_ID";
            this.CHK_ID.Size = new System.Drawing.Size(155, 30);
            this.CHK_ID.TabIndex = 7;
            // 
            // ID_Label
            // 
            this.ID_Label.AutoSize = true;
            this.ID_Label.BackColor = System.Drawing.Color.Transparent;
            this.ID_Label.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ID_Label.Font = new System.Drawing.Font("돋움", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ID_Label.ForeColor = System.Drawing.Color.Black;
            this.ID_Label.Location = new System.Drawing.Point(46, 45);
            this.ID_Label.Name = "ID_Label";
            this.ID_Label.Size = new System.Drawing.Size(72, 20);
            this.ID_Label.TabIndex = 6;
            this.ID_Label.Text = "아이디";
            // 
            // Login
            // 
            this.Login.Location = new System.Drawing.Point(75, 144);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(75, 23);
            this.Login.TabIndex = 5;
            this.Login.Text = "로그인";
            this.Login.UseVisualStyleBackColor = true;
            this.Login.Click += new System.EventHandler(this.Login_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.PowderBlue;
            this.panel3.Controls.Add(this.txb_Name);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.ckb_s);
            this.panel3.Controls.Add(this.ckb_h);
            this.panel3.Controls.Add(this.txb_pwc);
            this.panel3.Controls.Add(this.txb_pw);
            this.panel3.Controls.Add(this.Cancle);
            this.panel3.Controls.Add(this.sign_up2);
            this.panel3.Controls.Add(this.ID_check);
            this.panel3.Controls.Add(this.txb_ID);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(391, 266);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(38, 27);
            this.panel3.TabIndex = 9;
            // 
            // txb_Name
            // 
            this.txb_Name.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txb_Name.Location = new System.Drawing.Point(155, 20);
            this.txb_Name.Name = "txb_Name";
            this.txb_Name.Size = new System.Drawing.Size(187, 29);
            this.txb_Name.TabIndex = 32;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(14, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 19);
            this.label5.TabIndex = 31;
            this.label5.Text = "이름";
            // 
            // txb_pwc
            // 
            this.txb_pwc.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txb_pwc.Location = new System.Drawing.Point(155, 131);
            this.txb_pwc.Name = "txb_pwc";
            this.txb_pwc.Size = new System.Drawing.Size(187, 29);
            this.txb_pwc.TabIndex = 28;
            // 
            // txb_pw
            // 
            this.txb_pw.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txb_pw.Location = new System.Drawing.Point(155, 95);
            this.txb_pw.Name = "txb_pw";
            this.txb_pw.Size = new System.Drawing.Size(187, 29);
            this.txb_pw.TabIndex = 27;
            // 
            // Cancle
            // 
            this.Cancle.Location = new System.Drawing.Point(227, 233);
            this.Cancle.Name = "Cancle";
            this.Cancle.Size = new System.Drawing.Size(75, 23);
            this.Cancle.TabIndex = 26;
            this.Cancle.Text = "취소";
            this.Cancle.UseVisualStyleBackColor = true;
            this.Cancle.Click += new System.EventHandler(this.Cancle_Click);
            // 
            // sign_up2
            // 
            this.sign_up2.Location = new System.Drawing.Point(115, 233);
            this.sign_up2.Name = "sign_up2";
            this.sign_up2.Size = new System.Drawing.Size(75, 23);
            this.sign_up2.TabIndex = 25;
            this.sign_up2.Text = "회원가입";
            this.sign_up2.UseVisualStyleBackColor = true;
            this.sign_up2.Click += new System.EventHandler(this.sign_up2_Click);
            // 
            // ID_check
            // 
            this.ID_check.Location = new System.Drawing.Point(351, 57);
            this.ID_check.Name = "ID_check";
            this.ID_check.Size = new System.Drawing.Size(75, 23);
            this.ID_check.TabIndex = 24;
            this.ID_check.Text = "중복확인";
            this.ID_check.UseVisualStyleBackColor = true;
            this.ID_check.Click += new System.EventHandler(this.ID_check_Click);
            // 
            // txb_ID
            // 
            this.txb_ID.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txb_ID.Location = new System.Drawing.Point(155, 56);
            this.txb_ID.Name = "txb_ID";
            this.txb_ID.Size = new System.Drawing.Size(187, 29);
            this.txb_ID.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(13, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 19);
            this.label3.TabIndex = 21;
            this.label3.Text = "비밀번호 확인";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(13, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 19);
            this.label2.TabIndex = 20;
            this.label2.Text = "비밀번호";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(13, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 19);
            this.label1.TabIndex = 19;
            this.label1.Text = "아이디";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(13, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 19);
            this.label4.TabIndex = 22;
            this.label4.Text = "성별";
            // 
            // ckb_h
            // 
            this.ckb_h.AutoSize = true;
            this.ckb_h.Location = new System.Drawing.Point(174, 176);
            this.ckb_h.Name = "ckb_h";
            this.ckb_h.Size = new System.Drawing.Size(48, 16);
            this.ckb_h.TabIndex = 29;
            this.ckb_h.Text = "남성";
            this.ckb_h.UseVisualStyleBackColor = true;
            // 
            // ckb_s
            // 
            this.ckb_s.AutoSize = true;
            this.ckb_s.Location = new System.Drawing.Point(261, 176);
            this.ckb_s.Name = "ckb_s";
            this.ckb_s.Size = new System.Drawing.Size(48, 16);
            this.ckb_s.TabIndex = 30;
            this.ckb_s.Text = "여성";
            this.ckb_s.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(441, 305);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "로그인";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button sign_upx;
        private System.Windows.Forms.TextBox CHK_PS;
        private System.Windows.Forms.Label Passwordlb;
        private System.Windows.Forms.TextBox CHK_ID;
        private System.Windows.Forms.Label ID_Label;
        private System.Windows.Forms.Button Login;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txb_Name;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txb_pwc;
        private System.Windows.Forms.TextBox txb_pw;
        private System.Windows.Forms.Button Cancle;
        private System.Windows.Forms.Button sign_up2;
        private System.Windows.Forms.Button ID_check;
        private System.Windows.Forms.TextBox txb_ID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox ckb_s;
        private System.Windows.Forms.CheckBox ckb_h;
        private System.Windows.Forms.Label label4;
    }
}

